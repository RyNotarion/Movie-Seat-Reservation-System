<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Blog Site</title>
<?php include('./header.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=book");
?>
</head>

<style>
	body {
		width: 100%;
	    height: 100vh;
	    background: #000000; /* Dark movie-like background */
		display: flex;
		align-items: center;
		justify-content: center;
		color: #FFFFFF; /* White text for better contrast */
	}

	main#main {
		width: 100%;
		height: 100vh;
		display: flex;
		align-items: center;
		justify-content: center;
		background: rgba(0, 0, 0, 0.7); /* Semi-transparent dark background for a movie effect */
	}

	#login-right {
		width: 40%;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	#login-right .card {
		width: 100%;
		padding: 2rem;
		background: rgba(255, 255, 255, 0.1); /* Semi-transparent white background */
		backdrop-filter: blur(15px); /* Blurred background */
		border-radius: 15px;
		box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5); /* Stronger shadow for a cinematic look */
		color: #FFFFFF;
	}

	button.btn-primary {
		background: linear-gradient(45deg, #E50914, #8E9F74); /* Combined gradient for the button */
		border: none;
		color: white;
		padding: 10px;
		font-size: 16px;
		cursor: pointer;
		transition: background 0.3s ease, transform 0.2s ease; /* Smooth transition */
		border-radius: 8px;
	}

	button.btn-primary:hover {
		background: linear-gradient(45deg, #E50914, #D40812); /* Gradient changes slightly on hover */
	}

	button.btn-primary:active {
		background: linear-gradient(45deg, #4B8A29, #E50914); /* Change to green-red combo on click */
		transform: scale(0.95); /* Slightly shrink the button on click */
	}

	.form-control {
		background-color: rgba(255, 255, 255, 0.1); /* Transparent input fields */
		border: none;
		border-bottom: 1px solid #FFFFFF; /* Simple white border under fields */
		color: white;
	}

	.form-control:focus {
		background-color: rgba(255, 255, 255, 0.2);
		border-bottom: 1px solid #E50914; /* Red accent on focus */
		outline: none;
		box-shadow: none;
	}

	.control-label {
		color: #FFFFFF; /* White labels */
	}
</style>

<body>
  <main id="main" class="alert-info">
  		<div id="login-right">
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form id="login-form">
  						<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="text" id="username" name="username" class="form-control" required> 
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

</body>

<script>
	$('#login-form').submit(function(e){
		e.preventDefault();
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err);
				$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
			},
			success:function(resp){
				if(resp == 1){
					location.reload('index.php?page=home');
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>');
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		});
	});
</script>	
</html>
